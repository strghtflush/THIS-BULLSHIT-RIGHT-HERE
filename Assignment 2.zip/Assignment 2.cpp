//Alexander Robb
//Assignment 2
// 9-25-2016

#include "DeptstoreMember.h"
int main() {
	const int CUSTOMERS = 100;
	DeptstoreMember customers[CUSTOMERS];
	ifstream fin("DeptCustomers.txt");
	for (int i = 0; i < 100; i++) {
		if (!customers[i].ReadData(fin))
			break;
		cout << customers[i].FullName() << endl;
		cout << "Customer's undiscounted totals were: ";
		for (int j = 0; j < customers[i].numPrices; j++) {
			cout << customers[i].priceArray[j] << " ";
			}
					cout << endl;
					cout << "Customer's discounted totals were: ";
					for (int j = 0; j < customers[i].numPrices; j++) {
						cout << customers[i].DiscountedPrice(customers[i].priceArray[j]) << " ";
					}
					cout << endl;
					cout << "Reward Cash: " << customers[i].getRewardCash() << endl;
					if (customers[i].getRewardCash() >= 5.00)
						cout << "You can use your reward cash!" << endl << endl;
					else
						cout << "Keep saving so you can use your reward cash!" << endl << endl;
		}
	
	system("PAUSE");
	return 0;
}