//Alexander Robb
//Assignment 2
// 9-25-2016

#ifndef DEPTSTOREMEMBER_h
#define DEPTSTOREMEMBER_h

#include<string> //funny story, #include<string> and #include<cstring> are not the same thing!
#include<iostream>
#include<fstream>
using namespace std;



class DeptstoreMember {
public:
	DeptstoreMember(); // Default constructor
	DeptstoreMember(int IDnumber, string name); // different constructor
	void setIDNumber(int IDnumber); //sets ID Number for a member of the DeptstoreMember class
	void setFirstName(string name1); //sets first name for a member of the DeptstoreMember class
	void setLastName(string name2); //sets last name for a member of the DeptstoreMember class
	double getRewardCash(); //returns the current amount of reward cash in the account
	int getIDNumber(); //returns the ID number
	string getFirstName(); //returns the first name
	string getLastName(); //returns the last name
	string FullName(); // concatenates the first and last names in the form "Last name, First name"
	bool ReadData(ifstream & fin); // reads in data and checks if everything is running smoothly
	double DiscountedPrice(double originalPrice); //discounts the prices of the purchases and adds the reward cash appropriately
	double priceArray[10]; // array in which prices are stored
	int numPrices; //size of each member's price array
private:
	int ID_Number;
	double reward_cash = 0.0;
	string first_name;
	string last_name;
	string full_name;
};
#endif