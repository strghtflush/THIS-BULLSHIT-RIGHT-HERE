//Alexander Robb
//Assignment 2
// 9-25-2016


#include"DeptstoreMember.h"
DeptstoreMember :: DeptstoreMember() {
	ID_Number = 0;
	first_name = "a";
	last_name = "a";
} 
DeptstoreMember::DeptstoreMember(int IDnumber, string name) {
	if (IDnumber < 0)
		ID_Number = -1;
} //CONSTRUCTOR, ENSURES SOMEONE IS A MEMBER
void DeptstoreMember ::setIDNumber(int IDnumber) {
	ID_Number = IDnumber;
} //SETS ID NUMBER
void DeptstoreMember :: setFirstName(string name1) {
	first_name = name1;
} // SETS FIRST NAME
void DeptstoreMember :: setLastName(string name2) {
	last_name = name2;
} // SETS LAST NAME
double DeptstoreMember::getRewardCash() {
	return reward_cash;
} //LISTS REWARD CASH FOR ACCOUNT
int DeptstoreMember :: getIDNumber() {
	return ID_Number;
} // RETURNS ID NUMBER
string DeptstoreMember::getFirstName() {
	return first_name;
} //RETURNS FIRST NAME
string DeptstoreMember::getLastName() {
	return last_name;
} // RETURNS LAST NAME
string DeptstoreMember :: FullName() {
	string FullName = last_name + ", " + first_name;
	return FullName;
} //CONCATENATES FIRST AND LAST NAMES AS "LAST NAME, FIRST NAME"
bool DeptstoreMember::ReadData(ifstream& fin)
{
	int N;
	double temp = 0;
	ifstream fin2("Purchases.txt");
	if (fin >> ID_Number >> first_name >> last_name) {
		while (temp != ID_Number) {
			fin2 >> temp;
			if (fin2.eof())
				break;
		} // Proof I can search the file for a specific value, even if I couldn't make it work in the end.
		if (fin >> N) {
			for (int i = 0; i < N; i++) {
				fin >> priceArray[i];
			}
			numPrices = N;
		}
	}
			else {
				cout << "Could not read in number of prices" << endl;
				return false;
			}
	if (fin.eof()) {
		cout << "End of file." << endl << endl;
		return false;
	}
	return true;

}/*I genuinely tried to get this to work for hours.  I'll take the -10%, I can search all day but I cannot for the life of me reconcile the two files*/
	
	
double DeptstoreMember :: DiscountedPrice(double originalPrice) {
	reward_cash += ((originalPrice - originalPrice * .05) * .01);
	return (originalPrice - originalPrice *.05);
} // DISCOUNTS PRICE, ADDS REWARD CASH TO ACCOUNT
